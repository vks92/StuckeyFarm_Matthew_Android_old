package com.stuckeyfarm.pojo;

public class MyTicketPojo {


 public int id;

    public int   event_id=0;
    public String   name="";
    public String   description="";
    public int   price=0;
    public int    total=0;
    public int   pending=0;
    public int   status=0;


    public int   quntity=0;
    public boolean   isllQuantityShow=false;

    public MyTicketPojo(int id, int event_id, String name, String description, int price, int total, int pending, int status) {
        this.id = id;
        this.event_id = event_id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.total = total;
        this.pending = pending;
        this.status = status;
    }
}
