package com.stuckeyfarm.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import com.stuckeyfarm.R;
import com.stuckeyfarm.pojo.MypicModel;
import com.stuckeyfarm.pojo.Ticket_model;
import com.stuckeyfarm.utills.MySharedPreference;

import java.util.ArrayList;


public class TicketListAdapter extends RecyclerView.Adapter<TicketListAdapter.MyViewHolder> {

    public Context context;
    public TicketListAdapter(Context context) {

        this.context = context;
    }

    @Override
    public TicketListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_ticket, parent, false);
        return new TicketListAdapter.MyViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {



    }

    @Override
    public int getItemCount() {

        return 2;

    }

    public class MyViewHolder extends RecyclerView.ViewHolder {


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);


        }
    }
}
