package com.stuckeyfarm.Util;

/**
 * Created by test on 10/9/2017.
 */

public class Constants {

    public static String festival_date= "Please enter username";

}
