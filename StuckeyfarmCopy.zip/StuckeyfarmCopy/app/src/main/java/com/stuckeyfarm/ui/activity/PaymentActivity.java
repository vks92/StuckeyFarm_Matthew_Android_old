package com.stuckeyfarm.ui.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;

import com.stuckeyfarm.R;
import com.stuckeyfarm.Util.Parameters;
import com.stuckeyfarm.Util.util;
import com.stuckeyfarm.parser.AllStuckeyAPIS;
import com.stuckeyfarm.parser.GetAsyncPost;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.FormBody;
import okhttp3.RequestBody;
import okhttp3.Response;
import sqip.Callback;
import sqip.CardEntry;
import sqip.CardEntryActivityResult;
import sqip.InAppPaymentsSdk;


public class PaymentActivity extends AppCompatActivity implements View.OnClickListener {

    PaymentActivity context;
    private final Handler handler = new Handler(Looper.getMainLooper());
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

       startCardEntryActivity();

       Iniui();

//        if (InAppPaymentsSdk.INSTANCE.getSquareApplicationId().equals("REPLACE_ME")) {
//
//           // showMissingSquareApplicationIdDialog();
//
//        } else {
//
//           // showOrderSheet();
//        }

    }

    private void Iniui() {
        context=this;
    }
//    private void showMissingSquareApplicationIdDialog() {
//        new AlertDialog.Builder(this, R.style.Theme_AppCompat_Light_Dialog_Alert)
//                .setTitle(R.string.missing_application_id_title)
//                .setMessage(Html.fromHtml(getString(R.string.missing_application_id_message)))
//                .setPositiveButton(android.R.string.ok, (dialog, which) -> showOrderSheet())
//                .show();
//    }

        private void startCardEntryActivity() {

            CardEntry.startCardEntryActivity(this);
        }

//    private void showOrderSheet() {
//        orderSheet.show(PaymentActivity.this);
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        CardEntry.handleActivityResult(data, new Callback<CardEntryActivityResult>() {
            @Override
            public void onResult(CardEntryActivityResult cardEntryActivityResult) {

                if (cardEntryActivityResult.isSuccess()) {

//                    if (!ConfigHelper.serverHostSet()) {
//
//                        PaymentActivity.this.showServerHostNotSet();
//
//                    } else {
//
//                        PaymentActivity.this.showSuccessCharge();
//
//                    }

                } else if (cardEntryActivityResult.isCanceled()) {

                    Resources res = PaymentActivity.this.getResources();
                  //  int delayMs = res.getInteger(R.integer.card_entry_activity_animation_duration_ms);
                    //     handler.postDelayed(PaymentActivity.this, delayMs);

                }
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    public void showSuccessCharge() {
        showOkDialog(R.string.successful_order_title, getString(R.string.successful_order_message));
    }

    public void showServerHostNotSet() {
        showOkDialog(R.string.server_host_not_set_title, Html.fromHtml(getString(R.string.server_host_not_set_message)));
    }

    private void showOkDialog(int titleResId, CharSequence message) {
        new AlertDialog.Builder(this, R.style.Theme_AppCompat_Light_Dialog_Alert)
                .setTitle(titleResId)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, null)
                .show();

    }



//
//            if (ConnectivityReceiver.isConnected()) {
//
//                LoginApi();
//
//            } else {
//
//                util.Message(context, getString(R.string.no_internet), 1);
//



    private void ProcessPayment() {

        dialog = new ProgressDialog(context);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setIndeterminate(true);
        dialog.setCancelable(true);
        dialog.show();
        dialog.setContentView(R.layout.my_progress);
        FormBody.Builder formBuilder = new FormBody.Builder();
        formBuilder.add(Parameters.CARD_NONCE, "");
        formBuilder.add(Parameters.TOTAL_PRICE,  "");
        formBuilder.add(Parameters.EVENT_ID,  "");
        formBuilder.add(Parameters.TICKET_INFO,  "");
        formBuilder.add(Parameters.QUANTITY,  "");
        formBuilder.add(Parameters.EMAIL,  "");
        formBuilder.add(Parameters.LOCATION_ID,  "");
        formBuilder.add(Parameters.MOBILE_ID,  "");
        RequestBody formBody = formBuilder.build();
        GetAsyncPost mAsync = new GetAsyncPost(context, AllStuckeyAPIS.PROCESS_payment_Square, formBody, dialog, "") {
            @Override
            public void getValueParse(Response response) {
                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                dialog.dismiss();
                String result = "";

                try {

                    result = response.body().string();

                } catch (Exception e) {

                    e.printStackTrace();

                }

                Log.e("Login_response", "result " + result);

                JSONObject jsonObject = null;

                try {

                    jsonObject = new JSONObject(result);

                } catch (JSONException e) {

                    e.printStackTrace();

                }

                String m =   jsonObject.optString("message");


                //  Toast.makeText(LoginActivity.this, m, Toast.LENGTH_SHORT).show();
                if (response.isSuccessful()) {

                    try {

                        jsonObject = new JSONObject(result);

                        util.showToast(PaymentActivity.this, jsonObject.getString("message"));


                    } catch (JSONException e) {

                        e.printStackTrace();

                    }
                }

                else {

                    try {

                        jsonObject = new JSONObject(result);

                        util.showToast(PaymentActivity.this, jsonObject.getString("message"));

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void retry() {

            }
        };

        mAsync.execute();

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){


        }
    }
}